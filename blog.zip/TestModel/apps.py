from django.apps import AppConfig


class TestmodelConfig(AppConfig):
    name = 'TestModel'
