var x = 1;
function addX(value){
	return x + value;
}

//module.exports.x = x;
//module.exports.addX = addX;
export {addx};